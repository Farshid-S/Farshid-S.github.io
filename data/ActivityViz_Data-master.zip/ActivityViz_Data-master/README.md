## About

Data Storage for [ActivityViz](https://github.com/RSGInc/ActivityViz).